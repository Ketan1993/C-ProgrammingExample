#include "lcdDriver.h"
#include "LowLevelAsync.h"
#include "lcdDriver_Inst.h"


lcdBusMasterWriteFun lcdStringMaster;
static const FUNCTION_PRT const lcdMasterIntance[1] = {
    (FUNCTION_PRT)lcdStringMaster
};

typedef struct lcdInternal{
	lcdbus bus;
	struct lcdAsync_descriptor *m_instace;
	struct io_descripter *lcdIo;
}lcdInternal;


static lcdInternal lcdHardwareInst[1] = {
{
	{
		lcdMasterIntance,
		false
	}
}
};


bool lcdStringMaster(lcdbus *pcom, const uint8_t *buf)
{
	lcdInternal *lcdDisplay = (lcdInternal *)pcom;
	
	if(!lcdDisplay)
	return false;
	
	io_write(lcdDisplay->lcdIo, buf);
}

lcdbus *lcdDriverCreateForTest(uint8_t inst, bool status)
{
	lcdInternal *lcdDis = &lcdHardwareInst[inst];
	
	if(lcdDis->bus.m_allocate)
	 return false;
	 
	 lcdDis->bus.m_allocate = status;
	 lcdDis->m_instace = &LCD;
	 GetIo_descripter(lcdDis->m_instace, &lcdDis->lcdIo);
	 
	 return (lcdbus *)lcdDis;
}
