#include "lowLevel.h"

bool io_write(struct io_descripter *const iodevice, const uint8_t *buf)
{
	return iodevice->write(iodevice, buf);
}
