#include "boardinit.h"
#include "lcdDriver.h"
#include "lcdDisplay.h"
#include "ring_buffer.h"
#include "parser.h"
globalSt m_globalSt;

static boardDriverInt(void)
{
	lcdbus *lcd = NULL;
	lcd = lcdDriverCreateForTest(0, true);
	m_globalSt.pdisplay = lcdDisConfig(0, lcd);
	return;
}
void boardInit(void)
{
	 ringBuffer ringbuf;
     lcdDriverInit();
	 boardDriverInt();
	 static const uint8_t buf[5];
	 m_globalSt.pdisplay->DisplayAll(m_globalSt.pdisplay, "WELCOME");
	
	 ringBufferInit(&ringbuf, buf, sizeof(buf));
	 
	 ParselPoll();
	 uint8_t i;
	 uint8_t a;
	 for(i = 0; i < 6; i++)
	 {
	 	PushDataToRing(&ringbuf, i);
	 }
	 
	for(i = 0; i < 6; i++)
	 {
	  if(PopDataFromRing(&ringbuf, &a))
	      printf("%d\n", a);
	 }
	
}
