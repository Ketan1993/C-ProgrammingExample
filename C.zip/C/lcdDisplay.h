#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

typedef struct lcdbus lcdbus;
typedef struct lcdDisplay lcdDisplay;

struct lcdDisplay{
	bool (*DisplayAll)(lcdDisplay *lcdpcom, const uint8_t *buf);
	lcdbus *bus;
	bool m_allocate;
};

typedef lcdDisplay *(lcdDisplayConfig)(uint8_t inst, lcdbus *lcd);
lcdDisplayConfig lcdDisConfig;
