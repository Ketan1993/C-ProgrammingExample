#include <stdio.h>


//forward decalartion
typedef struct globalSt{
		 struct lcdDisplay *pdisplay;
}globalSt;
extern globalSt m_globalSt;

void boardInit(void);

