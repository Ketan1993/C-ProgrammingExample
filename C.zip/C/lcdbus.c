#include "lcdbus.h"

bool lcdMasterWrite(lcdbus *pcom, const uint8_t *buf)
{
	if(!pcom)
	   return false;
	   
	   const lcdBusMasterWriteFun *func = (const lcdBusMasterWriteFun *)
	   																	pcom->m_const.mfunc[MASTER_WRITE];
	   																	
	if(!func)
	    return false;
	    
	return (*func)(pcom, buf);
}
