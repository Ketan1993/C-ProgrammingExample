#include "cmdfun.h"

bool IF_CMDoutPut(const char *arg)
{
	printf("%s\n", arg);
	return true;
}

bool IF_CMDPrint(const char *arg)
{
	
	printf("%s\n", arg);
	return true;
}
