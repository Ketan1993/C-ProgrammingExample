#include "driver_init.h"

struct lcdAsync_descriptor LCD;

void lcdDriverInit(void)
{
	lcdPortInit(&LCD);
}
