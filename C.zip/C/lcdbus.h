#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>


typedef struct lcdbus lcdbus;
typedef void (*FUNCTION_PRT)(void);


#define MASTER_WRITE   0
struct lcdbus{
	
	const struct{
	    const FUNCTION_PRT *mfunc;
	    
	}m_const;
	bool m_allocate;
};

typedef bool (lcdBusMasterWriteFun)(lcdbus *pcom, const uint8_t *buf);
lcdBusMasterWriteFun lcdMasterWrite;
