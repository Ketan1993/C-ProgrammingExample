#include "lowLevelAsync.h"

static bool lcdWrite(struct io_descripter *const desc, const uint8_t *buf);


static bool lcdWrite(struct io_descripter *const desc, const uint8_t *buf)
{
	printf("%s\n", buf);
    return true;
}

bool lcdPortInit(struct lcdAsync_descriptor *const descr)
{
	descr->io.write  = lcdWrite;
	return true;
}

bool GetIo_descripter(struct lcdAsync_descriptor *const descr, struct io_descripter **io)
{
   *io = &descr->io;
   return true;
}
