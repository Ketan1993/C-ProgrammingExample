#include "lcdbus.h"

typedef lcdbus *(lcdDriverCreate)(uint8_t inst, bool status);
lcdDriverCreate lcdDriverCreateForTest;

