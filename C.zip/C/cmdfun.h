#include <stdio.h>
#include <stdbool.h>

bool IF_CMDoutPut(const char *arg);
bool IF_CMDPrint(const char *arg);
