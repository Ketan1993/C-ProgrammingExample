#include <stdio.h>
#include <stdint.h>

typedef struct ringBuffer ringBuffer;

struct ringBuffer{
	uint8_t *buffer;
	uint8_t size;
	uint8_t write;
	uint8_t read;
	
};

void ringBufferInit(ringBuffer *cb, const uint8_t *buf, int size);
int CheckForOverFlow(ringBuffer *cb);
int CheckForEmpty(ringBuffer *cb);
void PushDataToRing(ringBuffer *cb,  uint8_t buf);
int PopDataFromRing(ringBuffer *cb,  uint8_t *buf);

uint8_t ringbuffer_flush(ringBuffer *cb);
