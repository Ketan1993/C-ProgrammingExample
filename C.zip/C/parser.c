#include "parser.h"
#include "cmdfun.h"
#include <string.h>

typedef struct parserCommand{
	const char *cmd;
	uint8_t argMent;
	bool (*fun)(const char *arg);
	
}parserCommand;

typedef struct parserGroup{
	char ctrChar;  //this is the read only, can not change
	const parserCommand *cmd;
	uint8_t totalGroup;
}parserGroup;

static const parserCommand const colon[] = {
   
   {"A", 2, IF_CMDoutPut}
   
};

static const parserCommand const star[] = {
   
   {"A", 2, IF_CMDPrint}
   
};


static const parserGroup const parserTable[] = {
  {':',colon, (sizeof(colon)/sizeof(colon[0]))},
  {'*',star, (sizeof(star)/sizeof(star[0]))}
};

static int8_t findParserGroup(char *buf)
{
	int8_t status = CMD_STATUS_INVALID;
	uint8_t groupIdx;
	for(groupIdx = 0; groupIdx < (sizeof(parserTable)/sizeof(parserTable[0])); ++groupIdx)
	{
		if(buf[0] == parserTable[groupIdx].ctrChar)
		{
			status = groupIdx;
			break;
		}
	}
	return status;
}

static int8_t findParserCmd(const char *buf, uint8_t len, int8_t index)
{
	int8_t status = CMD_STATUS_INVALID;
	uint8_t cmdLen = 0;
	uint8_t argLen = 0;
	char cmd[CMD_LENGTH_MAX];
	//assign the index of parser table
	const parserGroup *CmdGrp = &parserTable[index];
	uint8_t loopIndex;
	
	for(loopIndex = 0; loopIndex < CmdGrp->totalGroup; ++loopIndex)
	{
		cmdLen = strlen(CmdGrp->cmd[loopIndex].cmd);
		argLen = CmdGrp->cmd[loopIndex].argMent;
		
		//check for excat command are matching 
		if((cmdLen + argLen) == len)
		{
			//skip the command in buf;
			strncpy(cmd, buf + 1, cmdLen);
			cmd[cmdLen] = '\0';
			
			//compare the cmd in group to get right function index
			if(!strcmp(cmd, CmdGrp->cmd[loopIndex].cmd))
			{
				status = loopIndex;
				break;
			}
		}
	}
	
	return status;
}

static int8_t CmdParser (char *buf, uint8_t len)
{
	int8_t ParserStatus = CMD_STATUS_INVALID;
	volatile int8_t cmdGroupId = 0;
	volatile int8_t cmdIndex = 0;
	parserGroup prGrp;
	//get group of cmd
	cmdGroupId = findParserGroup(buf);
	
	if(cmdGroupId != CMD_STATUS_INVALID)
	{
		//find a cmd index
	   cmdIndex	= findParserCmd(buf, len -1, cmdGroupId);
	   if(cmdIndex != CMD_STATUS_INVALID)
	   {
	   	  prGrp = parserTable[cmdGroupId];
	   	  // call the respective function from the structure.
	   	  ParserStatus = prGrp.cmd[cmdIndex].fun(buf + strlen(prGrp.cmd[cmdIndex].cmd) + 1); 
	   }
	}
	
	if(cmdGroupId == CMD_STATUS_INVALID)
   	   printf("GROUP NOT FOUND\n");
	if(cmdIndex == CMD_STATUS_INVALID)
       printf("COMMAND NOT FOUND\n");
	
	return ParserStatus;
}

void ParselPoll()
{
	char m_cmdData[CMD_LENGTH_MAX];
	printf("ENTER YOUR COMMAND\n");
	scanf("%s", &m_cmdData);
	CmdParser(m_cmdData, strlen(m_cmdData));
}
