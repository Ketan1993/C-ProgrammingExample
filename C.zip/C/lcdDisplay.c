#include "lcdDisplay.h"
#include "lcdbus.h"

bool function1(lcdDisplay *lcdpcom, const uint8_t *buf);

typedef struct lcdDisplayInternal{
	lcdDisplay m_display;
}lcdDisplayInternal;


static lcdDisplayInternal lcdDisplayInstance[1] = {
{
	{
		function1,
		NULL,
		false
	}
}
};

bool function1(lcdDisplay *lcdpcom, const uint8_t *buf)
{
	lcdDisplayInternal *lcdDis = (lcdDisplayInternal *)lcdpcom;
	
	if(!lcdDis)
	  return false;
	  
	lcdbus *pcom = lcdDis->m_display.bus; 
    lcdMasterWrite(pcom, buf);
	
	return true;  
}

lcdDisplay *lcdDisConfig(uint8_t inst, lcdbus *lcd)
{
	lcdDisplayInternal *lcdDis = &lcdDisplayInstance[inst];
	
	if(lcdDis->m_display.m_allocate)
	  return false;
	 lcdDis->m_display.m_allocate = true;
	 
	 if(!lcd)
	   return false;
	   
	 lcdDis->m_display.bus = lcd;
	 
	 return (lcdDisplay *)lcdDis;
	  
}
