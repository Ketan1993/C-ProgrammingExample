#include "lowLevel.h"

typedef struct lcdAsync_descriptor lcdAsync_descriptor;

struct lcdAsync_descriptor{
	struct io_descripter io;
};

bool lcdPortInit(struct lcdAsync_descriptor *const descr);
bool GetIo_descripter(struct lcdAsync_descriptor *const descr, struct io_descripter **io);
