#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

struct io_descripter io_descripter;
typedef bool (*low_level_write)(struct io_descripter *const iodevice, const uint8_t *buf);

struct io_descripter{
	low_level_write write;
};

bool io_write(struct io_descripter *const iodevice, const uint8_t *buf);
