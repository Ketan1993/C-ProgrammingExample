#include "ring_buffer.h"
#include <stdlib.h>

void ringBufferInit(ringBuffer *cb, const uint8_t *buf, int size)
{
   cb->size = size;
   cb->write = 0;
   cb->read = 0;
   cb->buffer = (uint8_t *)buf;
}

int CheckForOverFlow(ringBuffer *cb)
{
	if(cb->write == cb->size)
	  return 1;
	  
	  else  return 0;

}

int CheckForEmpty(ringBuffer *cb)
{
	if(cb->write == cb->read)
	  return 1;
	  
	else return 0;
}

void PushDataToRing(ringBuffer *cb,  uint8_t buf)
{
	//check first for overflow 
	int index;
	if(CheckForOverFlow(cb))
	   {
	   	 printf("STACT OVER FLOW\n");
	   	 return;
	   }
	   else
	    {
	    	   cb->buffer[cb->write] = buf;
               printf("%d\n", cb->buffer[cb->write]);

               cb->write++;
        }
}
uint8_t ringbuffer_flush(ringBuffer *cb)
{
	cb->read = cb->write;
}
int PopDataFromRing(ringBuffer *cb,  uint8_t *buf)
{
	if(CheckForEmpty(cb))
	 {
	   	  printf("STACT EMPTY\n");
	   	  return 0;
	 }
	if(cb->read != cb->write)
	{
	   *buf = cb->buffer[cb->read];
	    cb->read++;	
	    return 1;
	}
  return 0;
}
