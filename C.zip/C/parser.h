#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>


#define CMD_STATUS_INVALID -1
#define CMD_LENGTH_MAX 10

void ParselPoll();


